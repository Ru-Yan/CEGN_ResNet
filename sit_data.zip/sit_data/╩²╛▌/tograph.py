from os import read
import serial
import serial.tools.list_ports
import json
import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np
from mpl_toolkits.mplot3d import axes3d
from matplotlib.animation import FuncAnimation

def ToGraph(data):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    Z = np.array(data)
    x = np.arange(0,len(Z[0]),1)
    y = np.arange(0,len(Z),1)
    X,Y = np.meshgrid(x,y)
    #ax.plot_wireframe(X, Y, Z, rstride=1, cstride=1)
    ax.plot_surface(X, Y, Z, rstride = 1, cstride = 1,cmap = plt.get_cmap('rainbow'))
    plt.show()

file = input("请输入文件路径：")
file = open(file,"r")
lines = file.readlines()
data = []

for i in range(32):
    data.append([])
    
for i in lines:
    print(i)
    t = json.loads(i)
    rId = t["row"]
    data[rId] = t["data"]

ToGraph(data)
